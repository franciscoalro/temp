package com.lagradost.cloudstream3.plugins

@Suppress("unused")
@Target(AnnotationTarget.CLASS)
annotation class CloudstreamPlugin(
)