package com.lagradost.cloudstream3.ui.download

interface DownloadButtonViewHolder {
    var downloadButton : EasyDownloadButton
    fun reattachDownloadButton()
}