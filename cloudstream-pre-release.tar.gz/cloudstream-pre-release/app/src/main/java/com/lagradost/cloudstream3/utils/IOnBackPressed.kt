package com.lagradost.cloudstream3.utils

interface IOnBackPressed {
    fun onBackPressed(): Boolean
}